Main_inverse_kinematics(0, 100, 100)
