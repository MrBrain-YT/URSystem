import matlab.engine
import math as Math
import numpy as np


def Forward(J1, J2, J3, J4):
    eng = matlab.engine.start_matlab()
    gh = eng.Main_Fwd_Kinematics(J1, J2, J3, J4, nargout=1)
    print(gh[0][-1])
    print(gh[1][-1])
    print(gh[2][-1])

def Inverse(x,y,z):
    J1 = Math.atan2(0.0 + y, 0.0 + x) * 180.0 / Math.pi
    eng = matlab.engine.start_matlab()
    start = [0,0,0]
    end = [x,y,0]
    res = eng.main_inverse_kinematics(Math.sqrt(sum((end[i] - 0.0)**2 for i in range(len(start)))), -(z - 67.117), nargout=1)
    # return [J1, res[0][0], res[0][1], res[0][2]]
    return [J1, 0 + (90 - (res[0][0])), res[0][1], res[0][2]]

ang = Inverse(20, 400, 67.117)
print(ang)

print(Forward(ang[0],ang[1],-ang[2],-ang[3]))
# print(Forward(26.0,62.0,-90.0,-44.0))
